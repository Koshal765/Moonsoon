const Footer = () => {
  return (
    <div
      className="py-4 mt-5 text-center text-white bg-warning fw-bold"
      style={{  }}
    >
      © 2025 Monsoon Recipe Hub • Share the warmth
    </div>
  );
};

export default Footer;
