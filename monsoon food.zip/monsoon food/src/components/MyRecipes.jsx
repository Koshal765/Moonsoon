import React from 'react'

const MyRecipes = () => {
  return (
    <div>MyRecipes</div>
  )
}

export default MyRecipes